import { MenuItem } from '@/types/menu';

export const menuItems: MenuItem[] = [
  // Drinks
  {
    id: 'drink-1',
    name: 'โกโก้มิ้น',
    category: 'drinks',
    price: 65,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/coffee-drinks-XJuqCXCosEpA7rViGekru2.webp',
    description: 'โกโก้ร้อนเข้มข้นกับนมสด'
  },
  {
    id: 'drink-2',
    name: 'ชาเขียว',
    category: 'drinks',
    price: 50,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/coffee-drinks-XJuqCXCosEpA7rViGekru2.webp',
    description: 'ชาเขียวสดใหม่ร้อนหรือเย็น'
  },
  {
    id: 'drink-3',
    name: 'กาแฟเย็น',
    category: 'drinks',
    price: 60,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/coffee-drinks-XJuqCXCosEpA7rViGekru2.webp',
    description: 'กาแฟเย็นสดชื่น'
  },
  {
    id: 'drink-4',
    name: 'กาแฟร้อน',
    category: 'drinks',
    price: 55,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/coffee-drinks-XJuqCXCosEpA7rViGekru2.webp',
    description: 'กาแฟอเมริกาโน่ร้อน'
  },
  {
    id: 'drink-5',
    name: 'แลตเต้',
    category: 'drinks',
    price: 70,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/coffee-drinks-XJuqCXCosEpA7rViGekru2.webp',
    description: 'แลตเต้นุ่มนวล'
  },
  {
    id: 'drink-6',
    name: 'คาปูชิโน่',
    category: 'drinks',
    price: 75,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/coffee-drinks-XJuqCXCosEpA7rViGekru2.webp',
    description: 'คาปูชิโน่ฟองนมหนา'
  },
  // Food
  {
    id: 'food-1',
    name: 'เค้กช็อกโกแลต',
    category: 'food',
    price: 80,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/pastries-bakery-4TCrYZzzX3HKzNgKL3GmAC.webp',
    description: 'เค้กช็อกโกแลตเข้มข้น'
  },
  {
    id: 'food-2',
    name: 'ครัวซองต์',
    category: 'food',
    price: 55,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/pastries-bakery-4TCrYZzzX3HKzNgKL3GmAC.webp',
    description: 'ครัวซองต์เนยสดใหม่'
  },
  {
    id: 'food-3',
    name: 'แอปเปิลพาย',
    category: 'food',
    price: 65,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/pastries-bakery-4TCrYZzzX3HKzNgKL3GmAC.webp',
    description: 'แอปเปิลพายร้อนสดใหม่'
  },
  {
    id: 'food-4',
    name: 'มัฟฟิ่นบลูเบอร์รี่',
    category: 'food',
    price: 60,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/pastries-bakery-4TCrYZzzX3HKzNgKL3GmAC.webp',
    description: 'มัฟฟิ่นบลูเบอร์รี่อร่อย'
  },
  {
    id: 'food-5',
    name: 'ช็อกโกแลตช็อป',
    category: 'food',
    price: 70,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/pastries-bakery-4TCrYZzzX3HKzNgKL3GmAC.webp',
    description: 'คุกกี้ช็อกโกแลตช็อป'
  },
  {
    id: 'food-6',
    name: 'ชีสเค้ก',
    category: 'food',
    price: 85,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663355412726/3n7kUnpQ9WoZw9RumExWEX/pastries-bakery-4TCrYZzzX3HKzNgKL3GmAC.webp',
    description: 'ชีสเค้กนิวยอร์ก'
  }
];
