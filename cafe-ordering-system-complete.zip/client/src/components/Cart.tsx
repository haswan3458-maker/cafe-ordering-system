import { CartItem, MenuItem } from '@/types/menu';
import { Trash2, ShoppingBag, X } from 'lucide-react';
import { useState } from 'react';

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (menuItem: MenuItem, quantity: number) => void;
  onRemoveItem: (menuItem: MenuItem) => void;
  onCheckout: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Cart({
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  isOpen,
  onClose
}: CartProps) {
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const totalPrice = items.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    setIsCheckingOut(true);
    setTimeout(() => {
      onCheckout();
      setIsCheckingOut(false);
    }, 800);
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Cart Sidebar */}
      <div
        className={`fixed right-0 top-0 h-screen w-full sm:w-96 bg-card shadow-2xl transform transition-transform duration-300 z-50 flex flex-col ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        } lg:relative lg:translate-x-0 lg:w-96 lg:shadow-lg`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border bg-primary/5">
          <div className="flex items-center gap-2">
            <ShoppingBag className="text-accent" size={24} />
            <h2 className="text-xl font-bold text-primary">ตะกร้า</h2>
            {totalItems > 0 && (
              <span className="ml-2 bg-accent text-accent-foreground px-2 py-1 rounded-full text-sm font-semibold">
                {totalItems}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1 hover:bg-secondary rounded-lg transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag size={48} className="text-muted mb-4" />
              <p className="text-muted-foreground">ตะกร้าว่างเปล่า</p>
              <p className="text-sm text-muted-foreground mt-2">เลือกเมนูเพื่อเริ่มสั่งซื้อ</p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.menuItem.id}
                className="cafe-card p-3 animate-slide-in-up"
              >
                <div className="flex gap-3">
                  <img
                    src={item.menuItem.image}
                    alt={item.menuItem.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold text-primary">{item.menuItem.name}</h4>
                    <p className="text-sm text-muted-foreground">{item.menuItem.price} บาท</p>
                    <div className="flex items-center gap-2 mt-2">
                      <button
                        onClick={() =>
                          onUpdateQuantity(item.menuItem, Math.max(1, item.quantity - 1))
                        }
                        className="w-6 h-6 bg-secondary hover:bg-muted rounded text-sm font-bold transition-colors"
                      >
                        −
                      </button>
                      <span className="w-6 text-center font-semibold">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.menuItem, item.quantity + 1)}
                        className="w-6 h-6 bg-secondary hover:bg-muted rounded text-sm font-bold transition-colors"
                      >
                        +
                      </button>
                      <button
                        onClick={() => onRemoveItem(item.menuItem)}
                        className="ml-auto p-1 text-destructive hover:bg-destructive/10 rounded transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mt-2 pt-2 border-t border-border text-right">
                  <p className="text-sm font-semibold text-accent">
                    {item.menuItem.price * item.quantity} บาท
                  </p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-border p-4 space-y-3 bg-secondary/30">
            <div className="flex justify-between items-center text-lg font-bold">
              <span>รวมทั้งสิ้น:</span>
              <span className="text-accent text-2xl">{totalPrice} บาท</span>
            </div>
            <button
              onClick={handleCheckout}
              disabled={isCheckingOut}
              className={`w-full cafe-button ${isCheckingOut ? 'animate-bounce-gentle' : ''}`}
            >
              {isCheckingOut ? 'กำลังประมวลผล...' : 'สั่งซื้อ'}
            </button>
          </div>
        )}
      </div>
    </>
  );
}
