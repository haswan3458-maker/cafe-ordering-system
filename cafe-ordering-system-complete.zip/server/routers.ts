import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  menu: router({
    getAll: publicProcedure.query(() => db.getAllMenuItems()),
    getById: publicProcedure.input(z.number()).query(({ input }) => db.getMenuItemById(input)),
    getByCategory: publicProcedure.input(z.string()).query(({ input }) => db.getMenuItemsByCategory(input)),
  }),

  order: router({
    create: protectedProcedure
      .input(z.object({
        tableNumber: z.number(),
        items: z.array(z.object({
          menuItemId: z.number(),
          quantity: z.number(),
          pricePerItem: z.number(),
        })),
        specialNotes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const subtotal = input.items.reduce((sum, item) => sum + (item.pricePerItem * item.quantity), 0);
        const taxAmount = Math.floor(subtotal * 0.1);
        const totalPrice = subtotal + taxAmount;

        const orderId = await db.createOrder(
          {
            userId: ctx.user.id,
            tableNumber: input.tableNumber,
            totalPrice,
            taxAmount,
            specialNotes: input.specialNotes,
          },
          input.items.map(item => ({
            orderId: 0,
            menuItemId: item.menuItemId,
            quantity: item.quantity,
            pricePerItem: item.pricePerItem,
            subtotal: item.pricePerItem * item.quantity,
          }))
        );

        return { orderId, totalPrice, taxAmount };
      }),
    getById: publicProcedure.input(z.number()).query(({ input }) => db.getOrderById(input)),
    getByStatus: publicProcedure.input(z.enum(["pending", "in_progress", "completed", "cancelled"]))
      .query(({ input }) => db.getOrdersByStatus(input)),
    getItems: publicProcedure.input(z.number()).query(({ input }) => db.getOrderItems(input)),
    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(["pending", "in_progress", "completed", "cancelled"]),
      }))
      .mutation(({ input }) => db.updateOrderStatus(input.orderId, input.status)),
  }),
});

export type AppRouter = typeof appRouter;
